//
//  FigureTableViewController.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "FigureTableViewController.h"

@interface FigureTableViewController ()

@end

@implementation FigureTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    navTitle(@"", self);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 0;
}


@end
