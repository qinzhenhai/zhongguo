//
//  TB_Account.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "TB_Account.h"

@implementation TB_Account

// Insert code here to add functionality to your managed object subclass

@end
