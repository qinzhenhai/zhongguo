//
//  TB_Category+CoreDataProperties.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "TB_Category+CoreDataProperties.h"

@implementation TB_Category (CoreDataProperties)

@dynamic name;
@dynamic icon;
@dynamic attribute;
@dynamic attribute1;
@dynamic attribute2;
@dynamic attribute3;
@dynamic defaulticon;

@end
