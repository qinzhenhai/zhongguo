//
//  TB_Category.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "TB_Category.h"

@implementation TB_Category

// Insert code here to add functionality to your managed object subclass

@end
