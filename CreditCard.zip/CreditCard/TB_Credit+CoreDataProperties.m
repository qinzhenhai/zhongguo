//
//  TB_Credit+CoreDataProperties.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "TB_Credit+CoreDataProperties.h"

@implementation TB_Credit (CoreDataProperties)

@dynamic bankName;
@dynamic cardName;
@dynamic icon;
@dynamic amount;
@dynamic note;
@dynamic attribute;
@dynamic attribute1;
@dynamic attribute2;
@dynamic attribute3;
@dynamic remindType;
@dynamic repaymentdate;

@end
