//
//  TB_Credit.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "TB_Credit.h"

@implementation TB_Credit

// Insert code here to add functionality to your managed object subclass

@end
