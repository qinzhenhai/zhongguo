//
//  TB_History.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "TB_History.h"

@implementation TB_History

// Insert code here to add functionality to your managed object subclass

@end
