//
//  TB_Setting.m
//  CreditCard
//
//  Created by qq on 16/5/23.
//  Copyright © 2016年 qq. All rights reserved.
//

#import "TB_Setting.h"

@implementation TB_Setting

// Insert code here to add functionality to your managed object subclass

@end
